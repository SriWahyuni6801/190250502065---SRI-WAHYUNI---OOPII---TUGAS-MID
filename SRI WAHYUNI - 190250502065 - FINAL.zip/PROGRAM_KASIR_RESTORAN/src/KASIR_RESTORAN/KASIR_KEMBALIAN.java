package KASIR_RESTORAN;
public class KASIR_KEMBALIAN extends KASIR_HARGA {
    void viewtotal() {
        System.out.println("|==========[ PEMBAYARAN ]==========|");
        System.out.println("Total : Rp." +total);
    }
    public double hitungkembalian (double bayar) {
        byr = bayar;
        if (byr > total){
            kembalian = bayar-total;
            return kembalian;
        }
        else {
            kekurangan = (bayar-total)*(-1);
            return kekurangan;
        }
    }
    void viewkembalian(){
        if (byr >= total){
            System.out.println("Kembalian : Rp." +kembalian);
            System.out.println("|==========[ TERIMA KASIH ]==========|");
        }
        else {
            System.out.println("Silahkan membayar kembali, Uang Anda masih kurang Rp." +kekurangan);
        }
    }
    void pelunasan(double bayar){
        byr = bayar;
        System.out.println("Pembayaran ulang : Rp." +byr);
        if (kekurangan > byr) {
            kekurangan = kekurangan - byr;
            System.out.println("Silahkan membayar kembali, uang Anda masih kurang Rp." + kekurangan);
        }
        else if (kekurangan < byr){
            kembalian = byr - kekurangan;
            kekurangan = 0.0;
            System.out.println("Kembalian : Rp." + kembalian);
            System.out.println("|==========[ TERIMA KASIH ]==========|");
        }
        else if (kekurangan == byr){
            kekurangan = kekurangan = byr;
            System.out.println("|==========[ TERIMA KASIH ]==========|");
        }
    }
}
